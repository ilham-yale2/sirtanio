@extends('layout.main')
@section('css')
<style>
    #header .overlay {
        position: absolute;
        left: 0px;
        top: 0px;
        width: 100%;
        height: 100%;
        background-color: {{ $home->about_color }};
        opacity: 0.7;
    }
</style>
@endsection
@section('content')
<section class="section-about tf-bottom ">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="tf-about center wow fadeInUp">
                    <h1 class="title-about"> {!! $about->about_title !!}</h1>
                    <p class="text-about">
                        {!! $about->about_text !!}
                    </p>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <div class="tf-text-service wow fadeInUp">
                    <h1 class="title-about"> {!! $about->value_title !!} </h1>
                    <p class="text-about">
                        {!! $about->value_text !!}
                    </p>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="tf-text-service wow fadeInUp">
                    <h1 class="title-about"> {!! $about->vision_title !!} </h1>
                    <p class="text-about">
                        {!! $about->vision_text !!}
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-team">
    <div class="container">
        <div class="heading-team center">
            <h1 class="title-team-home wow fadeInUp">Our Special Member</h1>
        </div>
        <div class="themesflat-slider" data-margin="30" data-nav="false" data-dots="false" data-item="4"
            data-item2="2" data-item3="1">
            <div class="team1-carousel owl-carousel owl-theme">
                @foreach ($team as $item)
                <div class="team-box wow fadeInUp">
                    <div class=""> <img src="{{ asset('storage/' . $item->photo) }}" alt="{{ $item->photo }}"
                            class="img-team-box" style="width: 300px; height: 270px; object-fit: cover;"> </div>
                    <div class="list-team-box">
                            <h3 class="title-team-box"> {{ $item->name }} </h3>
                        <span class="icon-team">
                            {{ $item->position }}
                        </span>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</section>


<section class="section-service2">
    <div class="container">
        <div class="row">
            <div class="heading-service center wow fadeInUp">
                <h1 class="title-service">Our Partners </h1>
            </div>
            @foreach ($partner as $item)
            <div class="col-md-3 col-sm-3">
                <div class="tf-box-icon wow fadeInUp">
                    <img src="{{ asset('storage/' . $item->image) }}" style="width: 200px; height: 200px; object-fit: cover;" class="tf-icon margin-top--8" >
                </div>
            </div>
            @endforeach
        </div>
        <div class="button-sv center">
            <a class="gain-button" href="service.html">All Services</a>
        </div>
    </div>
</section>

<section class="section-history-style">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <div class="tf-img-history">
                    <img src="{{ asset('storage/' . $about->certificate_img) }}" alt="" class="img-1-history">
                    {{-- <img src="images/home/history-2.png" alt="" class="img-2-history">
                    <img src="images/home/history-3.png" alt="" class="img-3-history"> --}}
                </div>
            </div>

            <div class="col-md-6 col-sm-6">
                <div class="heading-history tf-heading wow fadeInUp">
                    {{-- <p class="subtitle-history ">Fresh Vegetables.</p> --}}
                    <h1 class="title-history">{!! $about->certificate_title !!}</h1>
                    <p class="text-history">{!! $about->certificate_text !!}</p>
                </div>

                <div class="button-history">
                    <a class="gain-button button-color color2" href="service-detail.html">All View More +</a>
                </div>
            </div>
        </div>
    </div>
</section>

{{-- <section class="section-banner parallax1">
    <div class="overlay-banner"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="tf-banner center wow fadeInUp">
                    <img src="images/home/15.png" alt="image" class="">
                    <div class="title-banner">A person who is specializes in this field
                        is called as “Agriculturists”.</div>
                    <div class="button-banner">
                        <a class="gain-button" href="team.html">Discover More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section> --}}

<section class="section-testimonials-style">
    <div class="container">
        <div class="row" >
            <div class="col-md-12">
                <div class="themesflat-slider" data-margin="0" data-nav="true" data-dots="false" data-item="1" data-item2="1" data-item3="1">
                    <div class="one-carousel next-prev2 owl-carousel owl-theme wow fadeInUp">
                        @foreach ($journey as $item)
                        <div class="testimonials-box-style">
                            <div class="slider-testi">
                                {{-- <img alt="image" src="images/download.jpg" /> --}}
                                <h3 class="title-testimonials">{!! $item->body !!}</h3>
                            </div>

                                <div class="title-designer-01"> {{ $item->year }}</div>
                        </div>
                        @endforeach

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


@endsection
