<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">

<head>
    <meta charset="UTF-8">
    <title> {{ $page }} </title>
    @yield('partial.meta')

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Boostrap style -->
    <link rel="stylesheet" type="text/css" href="{{ asset('/stylesheet/bootstrap.css') }}">

    <!-- Theme style -->
    <link rel="stylesheet" type="text/css" href="{{ asset('/stylesheet/style.css') }}">

    <!-- icon -->
    <link rel="stylesheet" type="text/css" href="{{ asset('/stylesheet/icon-1.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
        integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />


    <!-- animation -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <!-- Reponsive -->
    <link rel="stylesheet" type="text/css" href="{{ asset('/stylesheet/responsive.css') }}">

    <!-- Favicon and touch icons  -->
    <link href="{{ asset('/icon/apple-touch-icon-48-precomposed.png') }}" rel="apple-touch-icon-precomposed">
    <link href="{{ asset('/icon/apple-touch-icon-32-precomposed.png') }}" rel="apple-touch-icon-precomposed">
    <link href="{{ asset('/icon/favicon.png" rel="shortcut icon') }}">

    <!-- carousel -->
    <link rel="stylesheet" type="text/css" href="{{ asset('/stylesheet/owl.carousel.min.css') }}">

    {{-- COBA MODAL --}}
    {{-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"> --}}
    {{-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> --}}
    {{-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script> --}}
    {{-- <script>
        $(document).ready(function() {
            $("#myModal").modal('show');
        });
    </script> --}}

    <style>
        a.tngh {
            text-align: center;
        }

        h1.tngh {
            text-align: center;
        }

        img.mt {
            margin-top: 25px;
        }

        .link a {
            color: #e6c951

        }
        .link a:hover {
            text-decoration-line: underline;
        }
    </style>
</head>


<body class="counter-scroll ">

    <style>
        #walink:hover {
            text-decoration: underline;
        }
    </style>
    <!-- Preloader -->

    {{-- <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Modal Header</h4>
                </div>
                <div class="modal-body">
                    <p>Some text in the modal.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div> --}}
    {{-- <div class="preloader">
        <div class="clear-loading loading-effect-2">
            <span></span>
        </div>
    </div> --}}
    {{-- HEADER --}}


    @include('partial.head-landing')

    <section class="section-about">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="tf-about center">
                        <h1 class="title-about wow fadeInUp"> {!! $home->title !!} </h1>

                        {{-- <p class="inner-title-about">About Us Our History.</p> --}}
                        <p class="text-about">
                            {!! $home->sub_title !!}
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-service2">
        <div class="container">
            <div class="row">
                <div class="heading-service center wow fadeInUp">
                    <h1 class="title-service" style="margin-bottom: 100px">Benefits of organic red rice</h1>
                </div>
                @foreach ($benefit as $item)
                    {{-- @dd($item->icon) --}}
                    <div class="col-md-3 col-sm-3">
                        <div class="tf-box-icon wow fadeInUp">
                            {{-- <img src="{{ asset('storage/' . $item->icon) }}" class="tf-icon margin-top--8" style="max-height: 62px; max-width: 70px;"> --}}
                            <div class="tf-icon margin-top--8">

                                {!! $item->icon !!}
                            </div>
                            <p class="tf-text-icon">{{ $item->description }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
            {{-- <div class="button-sv center">
                <a class="gain-button" href="service.html">All Services</a>
            </div> --}}
        </div>
    </section>

    <section class="section-counter">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="heading-counter  wow fadeInUp">
                        {{-- <p class="subtitle-counter"> Service We Award.</p> --}}
                        <h3 class="title-counter">{!! $home->deskripsi !!}</h3>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="tf-wrap  wow fadeInUp">
                        <span class="counter"> <span class="number-counter counter-style72" data-from="0"
                                data-to="{{ $home->farmer }}" data-speed="2000"
                                data-inviewport="yes">{{ $home->farmer }}</span></span> <span class="counter-style72">
                        </span>
                        <div class="sub-text-counter">
                            <span class="color-black">FARMER PARTNER</span>
                            {{-- <span class="using">Per Day Using    Website.</span> --}}
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="tf-wrap  wow fadeInUp">
                        <span class="counter "> <span class="number-counter counter-style72" data-from="0"
                                data-to="{{ $home->land }}" data-speed="2000"
                                data-inviewport="yes">{{ $home->land }}</span></span> <span class="counter-style72">
                            ha </span>
                        <div class="sub-text-counter">
                            <span class="color-black">ORGANIC LAND AREA </span>
                            {{-- <span class="using">Per Day Using
                                Website.</span> --}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-portfolio">
        <h1 class="tngh wow fadeInUp">Our Product</h1>
        <div class="container">
            <div class="row">
                @foreach ($product as $item)
                    <div class="col-md-4 col-sm-4">
                        <div class="tf-gallery style-13 wow fadeInUp ">
                            <div class="-gallery">
                                <a class="popup-gallery" href="{{ asset('storage/' . $item->product_image) }}"> <img
                                        src="{{ asset('storage/' . $item->product_image) }}" alt=""
                                        class="img-galery " style="height: 490px; width:370px; object-fit:cover"></a>
                            </div>
                            <a href="http://bit.ly/sirtanioberasorganik" target="_blank" class="tngh wow fadeInUp">
                                <h3 class="">{{ $item->product_title }}</h3>
                            </a>
                        </div>
                    </div>
                @endforeach
                <div class="col-md-7">
                    <div class="button-portfolio wow fadeInUp">
                        <a class="gain-button button-color" href="/products">See Our Product</a>
                    </div>
                </div>
            </div>
    </section>



    <!-- footer -->
    @include('partial.footer')


    {{-- Javascript --}}
    <script src="{{ asset('/javascript/jquery.min.js') }}"></script>
    <script src="{{ asset('/javascript/bootstrap.min.js') }}"></script>
    <script src="{{ asset('/javascript/jquery.easing.js') }}"></script>
    <script src="{{ asset('/javascript/jquery-countTo.js') }}"></script>
    <script src="{{ asset('/javascript/jquery.cookie.js') }}"></script>
    <script src="{{ asset('/javascript/jquery.magnific-popup.min.js') }}"></script>

    <script src="{{ asset('/javascript/owl.carousel.min.js') }}"></script>

    <script src="{{ asset('/javascript/parallax.js') }}"></script>
    <script src="{{ asset('/javascript/main.js') }}"></script>

    {{-- animation --}}
    <script src="{{ asset('/javascript/wow.min.js') }}"></script>
    <script src="{{ asset('/javascript/animation.js') }}"></script>


    {{-- Revolution Slider --}}
    <script src="{{ asset('/rev-slider/js/jquery.themepunch.tools.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/jquery.themepunch.revolution.min.js') }}"></script>
    <script src="{{ asset('/javascript/rev-slider.js') }}"></script>

    {{-- Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading --> --}}
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.actions.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.carousel.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.kenburn.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.layeranimation.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.migration.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.navigation.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.parallax.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.slideanims.min.js') }}"></script>
    <script src="{{ asset('/rev-slider/js/extensions/revolution.extension.video.min.js') }}"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-TFR9S6GN89"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

    gtag('config', 'G-TFR9S6GN89');
    $(document).ready(function () {
        $(document).ready(function () {
            Swal.fire({
                imageUrl: '{{ asset("storage/" . $home->popup_img) }}',
                showCloseButton: true,
                showConfirmButton:false,
                width: '400px',
                height: '400px'
            })
            $('.swal2-image').click(function () {
                window.location.href = '{{ $home->link }}'
            })
        });
    });
        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-TFR9S6GN89');
    </script>


</body>

</html>
