{{-- Javascript --}}
<script src="{{ asset('/javascript/jquery.min.js') }}"></script>
<script src="{{ asset('/javascript/bootstrap.min.js') }}"></script>
<script src="{{ asset('/javascript/jquery.easing.js') }}"></script>
<script src="{{ asset('/javascript/jquery-countTo.js') }}"></script>
<script src="{{ asset('/javascript/jquery.cookie.js') }}"></script>
<script src="{{ asset('/javascript/jquery.magnific-popup.min.js') }}"></script>

<script src="{{ asset('/javascript/owl.carousel.min.js') }}"></script>

<script src="{{ asset('/javascript/parallax.js') }}">
</script><script src="{{ asset('/javascript/main.js') }}"></script>

{{-- animation --}}
<script src="{{ asset('/javascript/wow.min.js') }}"></script>
<script src="{{ asset('/javascript/animation.js') }}"></script>

{{--
Revolution Slider
<script src="{{ asset('/rev-slider/js/jquery.themepunch.tools.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/jquery.themepunch.revolution.min.js') }}"></script>
<script src="{{ asset('/javascript/rev-slider.js') }}"></script>

 Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading -->
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.actions.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.carousel.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.kenburn.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.layeranimation.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.migration.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.navigation.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.parallax.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.slideanims.min.js') }}"></script>
<script src="{{ asset('/rev-slider/js/extensions/revolution.extension.video.min.js') }}"></script> --}}
